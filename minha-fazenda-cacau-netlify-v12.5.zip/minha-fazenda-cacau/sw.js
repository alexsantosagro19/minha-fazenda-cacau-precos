/* Minha Fazenda Cacau — service worker
   A versão muda a cada publicação: é o que faz o aparelho buscar os arquivos novos.
   As bibliotecas do leitor (PDF.js e ZXing) ficam num cache próprio, que só muda
   quando elas mudarem, e são guardadas uma a uma: se uma falhar, o resto instala. */
const VERSAO = 'minha-fazenda-cacau-12.5';
const BIBLIOTECAS = 'minha-fazenda-cacau-bibliotecas-1';

const ARQUIVOS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icone-192.png",
  "./icone-512.png",
  "./icone-maskable-512.png",
  "./apple-touch-icon.png",
  "./favicon-64.png",
  "./vendor/leaflet.js",
  "./vendor/leaflet.css"
];
const LEITOR = [
  "./vendor/pdfjs/pdf.min.js",
  "./vendor/pdfjs/pdf.worker.min.js",
  "./vendor/pdfjs/wasm/jbig2.wasm",
  "./vendor/pdfjs/wasm/openjpeg.wasm",
  "./vendor/pdfjs/wasm/qcms_bg.wasm",
  "./vendor/zxing/zxing.min.js"
];
const ehBiblioteca = url => /\/vendor\/(pdfjs|zxing)\//.test(url);

self.addEventListener('install', ev => {
  ev.waitUntil(Promise.all([
    caches.open(VERSAO).then(c => c.addAll(ARQUIVOS)),
    caches.open(BIBLIOTECAS).then(c => Promise.all(LEITOR.map(u => c.match(u).then(ja => ja || c.add(u)).catch(() => null))))
  ]).then(() => self.skipWaiting()));
});

self.addEventListener('activate', ev => {
  ev.waitUntil(
    caches.keys()
      .then(chaves => Promise.all(chaves.filter(k => k !== VERSAO && k !== BIBLIOTECAS).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* só os arquivos do próprio app passam por aqui. Satélite, clima, preços e PRODES
   seguem direto para a internet, com o cache normal do navegador. */
self.addEventListener('fetch', ev => {
  if (ev.request.method !== 'GET') return;
  const url = new URL(ev.request.url);
  if (url.origin !== self.location.origin) return;
  const biblioteca = ehBiblioteca(url.pathname);
  ev.respondWith(
    caches.match(ev.request, {ignoreSearch: true}).then(guardado => {
      if (guardado && biblioteca) return guardado;
      const daRede = fetch(ev.request).then(resp => {
        if (resp && resp.status === 200 && resp.type === 'basic') {
          const copia = resp.clone();
          caches.open(biblioteca ? BIBLIOTECAS : VERSAO).then(c => c.put(ev.request, copia));
        }
        return resp;
      }).catch(() => guardado);
      return guardado || daRede;
    })
  );
});

/* lembrete do dia (enviado pela função lembrete-diario do Supabase) */
self.addEventListener('push', ev => {
  let d = {};
  try { d = ev.data ? ev.data.json() : {}; } catch (e) { d = {corpo: ev.data ? ev.data.text() : ''}; }
  ev.waitUntil(self.registration.showNotification(d.titulo || 'Minha Fazenda Cacau Pro', {
    body: d.corpo || 'Abra o app e registre o dia.', tag: d.tag || 'mfc-lembrete', renotify: false,
    icon: './icone-192.png', badge: './icone-192.png', lang: 'pt-BR', data: {url: './index.html?origem=lembrete'}
  }));
});
self.addEventListener('notificationclick', ev => {
  ev.notification.close();
  const alvo = new URL((ev.notification.data && ev.notification.data.url) || './', self.registration.scope).href;
  ev.waitUntil(self.clients.matchAll({type: 'window', includeUncontrolled: true}).then(lista => {
    for (const c of lista) if (c.url.startsWith(self.registration.scope) && 'focus' in c) return c.focus();
    return self.clients.openWindow(alvo);
  }));
});
